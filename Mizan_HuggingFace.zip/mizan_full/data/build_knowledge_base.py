import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
sc=json.loads((ROOT/'data/scenarios.json').read_text(encoding='utf-8'))
actions=json.loads((ROOT/'data/actions.json').read_text(encoding='utf-8'))
out=[]
for s in sc: out.append({'id':'scenario_'+s['id'],'type':'scenario','title':s['title'],'text':s['text']+' Options: '+' | '.join(o['text'] for o in s['options'])})
for a in actions: out.append({'id':'action_'+a['id'],'type':'action','title':a['title'],'text':a['description']})
policies=[('policy_scope','Mizan is a non-diagnostic wellbeing platform. It does not diagnose or replace professional care.'),('policy_deen','Mizan does not issue fatwas, judge religious sincerity, or invent religious claims. Refer specific rulings to a qualified scholar.'),('policy_safety','Safety/crisis decisions are deterministic and must not be delegated to the LLM. Escalation resources are surfaced conservatively.'),('policy_rag','The LLM may only personalize or summarize retrieved curated content. It must not invent actions, diagnoses, faith scores, or unsupported claims.'),('policy_profile','The Balance Profile is qualitative/descriptive only. No numeric Mind/Deen/Dunya scores.')]
for i,(k,t) in enumerate(policies): out.append({'id':k,'type':'policy','title':k.replace('_',' ').title(),'text':t})
(ROOT/'data/knowledge_base.jsonl').write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in out)+'\n',encoding='utf-8')
print(f'Wrote {len(out)} chunks')
