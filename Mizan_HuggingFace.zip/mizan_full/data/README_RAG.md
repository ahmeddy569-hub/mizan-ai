# Mizan RAG Dataset

The RAG corpus is `knowledge_base.jsonl`.

It is built from:
- 30 curated Mind/Deen/Dunya scenarios
- 9 curated actions/resources
- 5 safety/scope/policy documents

Important: RAG is **not model training**. The LLM is not fine-tuned on these rows. At question time, Mizan retrieves the most relevant reviewed chunks and supplies them to the LLM as context. The LLM is explicitly instructed not to invent actions, diagnoses, faith scores, or religious rulings.

To rebuild the corpus after editing scenarios/actions:
```bash
python data/build_knowledge_base.py
```
