---
title: Mizan — Mind Deen Dunya Wellbeing Platform
emoji: ⚖️
colorFrom: blue
colorTo: indigo
sdk: docker
app_port: 7860
pinned: false
short_description: Non-diagnostic wellbeing platform using Rules + curated knowledge + constrained RAG.
---

# Mizan — Full Graduation Project MVP

Mizan is a **non-diagnostic** wellbeing web application organized around Mind, Deen, and Dunya. It combines a deterministic rules layer, curated scenario/action content, a local RAG retriever, and an optional OpenAI-compatible LLM.

## Hugging Face Spaces deployment

This repository is prepared as a **Docker Space**. Hugging Face Docker Spaces support custom applications such as FastAPI and expect the application to listen on port `7860`.

1. Create a new Hugging Face Space.
2. Choose **Docker** as the SDK.
3. Choose the hardware you want.
4. Upload all files/folders in this repository to the Space root.
5. Wait for the Space to build.
6. Open the generated Space URL.

## AI configuration

The application works without an external LLM key: local RAG retrieval still runs and shows the closest curated knowledge.

For generated answers, add these as **Secrets/Variables** in the Space settings:

```text
LLM_API_KEY=your_key
LLM_BASE_URL=https://api.openai.com/v1
LLM_MODEL=your_model_name
```

Do not put real API keys inside the repository.

## Architecture

Frontend (RTL web) → FastAPI backend → SQLite → Rules Engine / Scenario Engine / Action Library / Safety Layer → RAG retriever → optional constrained LLM.

## Implemented

- Arabic RTL responsive frontend
- onboarding + explicit consent
- 30 curated scenario questions across Mind / Deen / Dunya
- deterministic balanced question selection
- qualitative, non-numeric Balance Profile
- curated action/resource library
- 3-question reflection loop
- progress tracking
- independent conservative safety keyword layer
- RAG over curated knowledge base
- optional constrained LLM generation
- chat logging
- user data deletion endpoint/UI
- health endpoint and automatic SQLite initialization

## Important scope

This is a graduation-project MVP, not a clinical or religious-authority system. The project should not diagnose users, generate faith scores, issue fatwas, or allow the LLM to make safety decisions.

## Local run

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000`.

## RAG

`data/knowledge_base.jsonl` contains curated scenario/action/policy chunks. Retrieval uses local TF-IDF character n-grams. This is retrieval, **not fine-tuning or custom model training**.

## Data persistence on Spaces

The app uses `/data/mizan.db` at runtime. A normal container restart can reset local container storage. For a real persistent deployment, attach a persistent storage solution or move the database to a managed external database.

## API

- GET `/api/health`
- POST `/api/onboard`
- GET `/api/scenarios/{user_id}`
- POST `/api/answer`
- GET `/api/profile/{user_id}`
- POST `/api/reflection`
- POST `/api/progress`
- POST `/api/ask`
- GET `/api/actions`
- GET `/api/me/{user_id}`
- DELETE `/api/me/{user_id}`

## Production checklist

For real deployment, replace SQLite with a managed database, add proper authentication/session tokens, encrypt sensitive data, configure access controls and retention/deletion policies, use HTTPS, review consent/legal text, have Deen content reviewed by qualified scholars, and conduct security/ethics testing.
