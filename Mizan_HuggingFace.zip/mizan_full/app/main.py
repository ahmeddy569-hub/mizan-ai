import json, os, re, sqlite3
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional
import requests
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Header
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from app.rag import retrieve

load_dotenv()
ROOT=Path(__file__).resolve().parent.parent
DB=Path(os.getenv('MIZAN_DB', '/data/mizan.db'))
DB.parent.mkdir(parents=True, exist_ok=True)
SCENARIOS=json.loads((ROOT/'data/scenarios.json').read_text(encoding='utf-8'))
ACTIONS=json.loads((ROOT/'data/actions.json').read_text(encoding='utf-8'))
CRISIS_WORDS=['انتحر','انتحار','أقتل نفسي','اقتل نفسي','مش عايز أعيش','مش عايز اعيش','إيذاء نفسي','ايذاء نفسي','أؤذي نفسي','اوذي نفسي','suicide','kill myself','self harm','self-harm']
DOMAINS=['mind','deen','dunya']
app=FastAPI(title='Mizan API',version='1.0.0',description='Non-diagnostic wellbeing platform: Rules + curated library + constrained RAG')
app.mount('/static',StaticFiles(directory=ROOT/'static'),name='static')

def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    c=conn(); c.executescript('''
    PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,consent INTEGER NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS answers(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,scenario_id TEXT NOT NULL,option_id TEXT NOT NULL,tags TEXT NOT NULL,created_at TEXT NOT NULL,UNIQUE(user_id,scenario_id),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS reflections(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,q1 TEXT,q2 TEXT,q3 TEXT,created_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS progress(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,action_id TEXT NOT NULL,done INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(user_id,action_id),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
    CREATE TABLE IF NOT EXISTS chat_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,message TEXT NOT NULL,answer TEXT NOT NULL,safety INTEGER NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
    '''); c.commit(); c.close()
init_db()

class Onboard(BaseModel): name:str=Field(default='User',max_length=80); consent:bool
class Answer(BaseModel): user_id:int; scenario_id:str; option_id:str
class Reflection(BaseModel): user_id:int; q1:str=Field(default='',max_length=1000); q2:str=Field(default='',max_length=1000); q3:str=Field(default='',max_length=1000)
class Progress(BaseModel): user_id:int; action_id:str; done:bool
class Ask(BaseModel): user_id:int; message:str=Field(min_length=1,max_length=3000)

def now(): return datetime.now(timezone.utc).isoformat()
def safety(text):
    t=text.lower().replace('أ','ا').replace('إ','ا').replace('آ','ا')
    return [w for w in CRISIS_WORDS if w.lower() in t]
def user_exists(uid):
    c=conn(); r=c.execute('SELECT id FROM users WHERE id=?',(uid,)).fetchone(); c.close(); return bool(r)
def rows(uid):
    c=conn(); r=c.execute('SELECT * FROM answers WHERE user_id=? ORDER BY id',(uid,)).fetchall(); c.close(); return r

def get_scenario(sid): return next((s for s in SCENARIOS if s['id']==sid),None)
def get_action(aid): return next((a for a in ACTIONS if a['id']==aid),None)

def profile(uid):
    positive={'planning','coping','reflection','growth','support','focus','routine','reset','action','awareness','self_care','goals','communication','habit','meaning','trusted_source','environment','priorities','balance','deen_action'}
    attention={'avoidance','distraction','rumination','self_criticism','overload','all_or_nothing','comparison','impulsivity','delay','isolation','unverified','screen','pressure','reactive','instability','motivation','checklist','automatic','overplanning'}
    counts={d:{'positive':0,'attention':0,'responses':0} for d in DOMAINS}
    for r in rows(uid):
        s=get_scenario(r['scenario_id']); tags=json.loads(r['tags'])
        d=s['domain']; counts[d]['responses']+=1
        counts[d]['positive']+=sum(t in positive for t in tags)
        counts[d]['attention']+=sum(t in attention for t in tags)
    out={}
    for d,v in counts.items():
        if v['responses']==0: label='معلومات غير كافية حتى الآن'
        elif v['attention']>v['positive']: label='نمط يستحق الانتباه'
        elif v['positive']>0: label='نمط/نقطة قوة مفيدة'
        else: label='قيد الاستكشاف'
        out[d]={'label':label,'responses':v['responses']}
    return out

def choose_actions(uid):
    tagset=[]
    for r in rows(uid): tagset.extend(json.loads(r['tags']))
    scored=[]
    for a in ACTIONS: scored.append((sum(t in tagset for t in a['tags']),a))
    return [a for score,a in sorted(scored,key=lambda x:x[0],reverse=True)[:5]]

def require_user(uid):
    if not user_exists(uid): raise HTTPException(404,'User not found')

@app.get('/')
def home(): return FileResponse(ROOT/'static/index.html')
@app.get('/api/health')
def health(): return {'status':'ok','service':'mizan','version':'1.0.0'}

@app.post('/api/onboard')
def onboard(x:Onboard):
    if not x.consent: raise HTTPException(400,'Explicit consent is required before storing responses.')
    c=conn(); cur=c.execute('INSERT INTO users(name,consent,created_at) VALUES(?,?,?)',(x.name.strip() or 'User',1,now())); c.commit(); uid=cur.lastrowid; c.close(); return {'user_id':uid}

@app.get('/api/scenarios/{uid}')
def next_scenario(uid:int):
    require_user(uid); answered={r['scenario_id'] for r in rows(uid)}; remaining=[s for s in SCENARIOS if s['id'] not in answered]
    if not remaining: return {'done':True,'scenario':None,'progress':len(answered),'total':len(SCENARIOS)}
    counts={d:0 for d in DOMAINS}
    for r in rows(uid): counts[get_scenario(r['scenario_id'])['domain']]+=1
    d=min(counts,key=counts.get)
    s=next((x for x in remaining if x['domain']==d),remaining[0])
    safe={k:v for k,v in s.items() if k!='review_notes'}
    return {'done':False,'scenario':safe,'progress':len(answered),'total':len(SCENARIOS)}

@app.post('/api/answer')
def answer(x:Answer):
    require_user(x.user_id); s=get_scenario(x.scenario_id)
    if not s: raise HTTPException(404,'Scenario not found')
    o=next((o for o in s['options'] if o['id']==x.option_id),None)
    if not o: raise HTTPException(400,'Option not found')
    c=conn()
    try: c.execute('INSERT INTO answers(user_id,scenario_id,option_id,tags,created_at) VALUES(?,?,?,?,?)',(x.user_id,x.scenario_id,x.option_id,json.dumps(o['tags'],ensure_ascii=False),now())); c.commit()
    except sqlite3.IntegrityError: raise HTTPException(409,'Already answered')
    finally: c.close()
    return {'ok':True,'next':True}

@app.get('/api/profile/{uid}')
def get_profile(uid:int):
    require_user(uid); return {'profile':profile(uid),'actions':choose_actions(uid),'non_diagnostic':True,'notice':'وصفي فقط وليس تشخيصاً أو درجة دينية.'}

@app.post('/api/reflection')
def reflection(x:Reflection):
    require_user(x.user_id); text=' '.join([x.q1,x.q2,x.q3]); hits=safety(text)
    if hits: return {'safety':True,'message':'لو في خطر فوري أو أفكار لإيذاء نفسك، تواصل الآن مع شخص تثق به أو خدمة طوارئ/أزمة مؤهلة. ميزان لا يقدم علاجاً أو استشارة أزمات.'}
    c=conn(); c.execute('INSERT INTO reflections(user_id,q1,q2,q3,created_at) VALUES(?,?,?,?,?)',(x.user_id,x.q1,x.q2,x.q3,now())); c.commit(); c.close(); return {'ok':True,'safety':False}

@app.post('/api/progress')
def progress(x:Progress):
    require_user(x.user_id)
    if not get_action(x.action_id): raise HTTPException(404,'Action not found')
    c=conn(); ts=now(); c.execute('INSERT INTO progress(user_id,action_id,done,created_at,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(user_id,action_id) DO UPDATE SET done=excluded.done,updated_at=excluded.updated_at',(x.user_id,x.action_id,int(x.done),ts,ts)); c.commit(); c.close(); return {'ok':True}

@app.post('/api/ask')
def ask(x:Ask):
    require_user(x.user_id); hits_s=safety(x.message)
    if hits_s:
        answer='أنا مش هقدر أتعامل مع ده كحالة عادية. لو في خطر فوري أو نية لإيذاء نفسك، تواصل فوراً مع شخص تثق به أو خدمات الطوارئ/الأزمة المؤهلة في بلدك. ميزان لا يقدم علاجاً أو استشارة أزمات.'
        c=conn(); c.execute('INSERT INTO chat_logs(user_id,message,answer,safety,created_at) VALUES(?,?,?,?,?)',(x.user_id,x.message,answer,1,now())); c.commit(); c.close(); return {'safety':True,'answer':answer,'retrieved':[]}
    hits=retrieve(x.message,k=5)
    context='\n'.join([f"[{h['id']}] {h['title']}: {h['text']}" for h in hits])
    answer=None
    key=os.getenv('LLM_API_KEY')
    if key:
        try:
            base=os.getenv('LLM_BASE_URL','https://api.openai.com/v1').rstrip('/'); model=os.getenv('LLM_MODEL','gpt-4o-mini')
            system=f'''You are Mizan, a non-diagnostic wellbeing assistant. Respond in clear Arabic. Use ONLY the curated context below. Never diagnose. Never produce numeric wellbeing or faith scores. Never give a fatwa or judge religious sincerity/correctness. If asked for a religious ruling, recommend a qualified scholar. Do not invent actions/resources. If context is insufficient, say so. Keep advice small, practical, and non-deterministic. Context:\n{context}'''
            rr=requests.post(base+'/chat/completions',headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},json={'model':model,'messages':[{'role':'system','content':system},{'role':'user','content':x.message}],'temperature':0.15},timeout=25)
            rr.raise_for_status(); answer=rr.json()['choices'][0]['message']['content']
        except Exception: answer=None
    if not answer:
        answer='مساعد ميزان يعمل حاليًا بوضع المعرفة المراجعة. لم أجد إجابة مولدة مناسبة، لكن هذه أقرب مواد داخل قاعدة المعرفة. يمكنك صياغة سؤالك بشكل أكثر تحديدًا.'
    c=conn(); c.execute('INSERT INTO chat_logs(user_id,message,answer,safety,created_at) VALUES(?,?,?,?,?)',(x.user_id,x.message,answer,0,now())); c.commit(); c.close()
    return {'safety':False,'answer':answer,'retrieved':hits}

@app.get('/api/dashboard/{uid}')
def dashboard(uid:int):
    require_user(uid); c=conn(); ans=c.execute('SELECT COUNT(*) n FROM answers WHERE user_id=?',(uid,)).fetchone()['n']; done=c.execute('SELECT COUNT(*) n FROM progress WHERE user_id=? AND done=1',(uid,)).fetchone()['n']; refs=c.execute('SELECT COUNT(*) n FROM reflections WHERE user_id=?',(uid,)).fetchone()['n']; chats=c.execute('SELECT COUNT(*) n FROM chat_logs WHERE user_id=?',(uid,)).fetchone()['n']; c.close(); return {'answered':ans,'total_scenarios':len(SCENARIOS),'actions_done':done,'reflections':refs,'chat_messages':chats}

@app.get('/api/actions')
def actions(): return {'actions':ACTIONS}

@app.get('/api/me/{uid}')
def me(uid:int):
    require_user(uid); c=conn(); u=c.execute('SELECT id,name,consent,created_at FROM users WHERE id=?',(uid,)).fetchone(); c.close(); return dict(u)

@app.delete('/api/me/{uid}')
def delete_me(uid:int):
    require_user(uid); c=conn(); c.execute('DELETE FROM users WHERE id=?',(uid,)); c.commit(); c.close(); return {'ok':True,'message':'User data deleted.'}
