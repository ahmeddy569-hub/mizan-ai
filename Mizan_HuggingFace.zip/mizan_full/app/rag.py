import json
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
ROOT=Path(__file__).resolve().parent.parent
KB=ROOT/'data/knowledge_base.jsonl'
DOCS=[json.loads(x) for x in KB.read_text(encoding='utf-8').splitlines() if x.strip()]
TEXTS=[d.get('title','')+' '+d.get('text','') for d in DOCS]
V=TfidfVectorizer(analyzer='char',ngram_range=(2,5),sublinear_tf=True,min_df=1)
M=V.fit_transform(TEXTS)
def retrieve(query,k=5):
    q=V.transform([query]); scores=cosine_similarity(q,M)[0]; idx=scores.argsort()[::-1][:k]
    return [{**DOCS[i],'score':round(float(scores[i]),4)} for i in idx if scores[i]>0]
