from fastapi.testclient import TestClient
from app.main import app

def test_health():
    c=TestClient(app); assert c.get('/api/health').status_code==200

def test_onboard_requires_consent():
    c=TestClient(app); assert c.post('/api/onboard',json={'name':'x','consent':False}).status_code==400
